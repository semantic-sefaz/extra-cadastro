from bs4 import BeautifulSoup
import requests
import re
import os
import shutil
import json
from datetime import date, timedelta, datetime
import time
import csv, zipfile, io

PATH_DATA = 'data/'
PATH_EMPRESA = 'empresa/'
PATH_ESTABELECIMENTO = 'estabelecimento/'
PATH_SOCIO = 'socio/'
PATH_SIMEI = 'simei/'
PATH_CNAE = 'cnae/'
PATH_MUNICIPIO = 'municipio/'
PATH_NAT_JU = 'nat_ju/'
PATH_PAIS = 'pais/'
PATH_QUALIF_SOCIO = 'qualif_socio/'
PATH_LOG = 'log/'
nome_arq = None

#URL = "http://portaltransparencia.gov.br/download-de-dados/ceis"
#URL = "https://portaltransparencia.gov.br/download-de-dados/ceis/20211129"
URL = "https://portaltransparencia.gov.br/download-de-dados/ceis/{0}".format(time.strftime("%Y%m%d"))
URL_ONTEM = "https://portaltransparencia.gov.br/download-de-dados/ceis/{0}".format((datetime.now()-timedelta(days=1)).strftime("%Y%m%d"))
print(URL)

path_sqlldr = "C:\\oraclexe\\app\\oracle\\product\\11.2.0\\server\\bin\\"
path_sqlldr_sefaz = "/u01/app/oracle/product/12.2.0/db_1/bin/"
path_carga = "C:\\proj-sefaz-ma\\rfb-sefaz-ma\\EmIS\\log\\"

username = 'ufc2'#'lano'
password = 'homo234'#'lanobl'
dsn = '172.20.3.59/homo01'#'localhost/xe'
port = 1521
encoding_db = 'UTF-8'
banco_dados = "//172.20.3.59:1521/homo01"#"xe"

arq_ctl_portal_transparecia_ceis = "ceis.ctl"

if not os.path.isdir(PATH_DATA): #Diretório de arquivos não existe
    os.mkdir(PATH_DATA)

if not os.path.isdir(PATH_LOG): #Diretório de arquivos não existe
    os.mkdir(PATH_LOG)

for file in os.listdir(PATH_DATA):
    os.remove(PATH_DATA+file)

print("Solicitando página do portal da transparencia em ",URL)
page = requests.get(URL, verify=False)
if page.status_code != requests.codes.ok:
    page = requests.get(URL_ONTEM, verify=False)

z = zipfile.ZipFile(io.BytesIO(page.content))
nome_arq = z.infolist()[0].filename
s = z.extractall()
os.rename(nome_arq,'CEIS.csv')
nome_arq = "CEIS.csv"
shutil.move(nome_arq,PATH_DATA+nome_arq)
print(s)

"""
#faz a carga em 3 tabelas
if arq_inab_csv:
    sql_loader = "{0}sqlldr userid={1}/{2}@{3} control={4}{5} log={4}inabilitados.log".format(path_sqlldr,username,password,banco_dados,path_carga,arq_ctl_tcu_fornecedor_inabilitado)
    sql_loader = "{0}sqlldr userid={1}/{2}@{3} control={4}{5} log={4}ceis.log".format(path_sqlldr_sefaz,username,password,banco_dados,path_carga,arq_ctl_portal_transparecia_ceis)
    ldr_inab = subprocess.call(sql_loader, shell=True)

if os.path.isfile(path_carga+"tcu_fornecedor_inabilitado.bad"):
    if os.stat(path_carga+"tcu_fornecedor_inabilitado.bad")[6] == 0.0:
        print("Falha na carga da tabela tcu_fornecedor_inabilitado")
    else:
        arq_inab_csv = True
        print("OK!")
"""
"""
1"TIPO DE PESSOA"
2;"CPF OU CNPJ DO SANCIONADO"
3;"NOME INFORMADO PELO ÓRGÃO SANCIONADOR"
4;"RAZÃO SOCIAL - CADASTRO RECEITA"
5;"NOME FANTASIA - CADASTRO RECEITA"
6;"NÚMERO DO PROCESSO"
7;"TIPO SANÇÃO"
8;"DATA INÍCIO SANÇÃO"
9;"DATA FINAL SANÇÃO"
10;"ÓRGÃO SANCIONADOR"
11;"UF ÓRGÃO SANCIONADOR"
12;"ORIGEM INFORMAÇÕES"
13;"DATA ORIGEM INFORMAÇÕES"
14;"DATA PUBLICAÇÃO"
15;"PUBLICAÇÃO"
16;"DETALHAMENTO"
17;"ABRAGÊNCIA DEFINIDA EM DECISÃO JUDICIAL"
18;"FUNDAMENTAÇÃO LEGAL"
19;"DESCRIÇÃO DA FUNDAMENTAÇÃO LEGAL"
20;"DATA DO TRÂNSITO EM JULGADO"
21;"COMPLEMENTO DO ÓRGÃO"
22;"OBSERVAÇÕES"
"J";"02921714000168";"Nit Clean Service Ltda";"NIT CLEAN SERVICE LTDA.";"WASH HOME";"07/10/002274/2010";"Inidoneidade - Legislação Municipal";"03/05/2013";"";"Prefeitura da Cidade do Rio de Janeiro";"RJ";"Prefeitura Municipal da Cidade do Rio de Janeiro (RJ)";"19/05/2016";"03/05/2013";"Diário Oficial do Município Seção 31 Pagina 70";"";"Na Esfera e no Poder do órgão sancionador";"Art. 597, Decreto 3221/1981";"Será declarado inidôneo para licitar e contratar com a Administração Municipal todo aquele que se mantiver na situação prevista no artigo por mais de 30 (trinta) dias, contados do início da suspensão.Parágrafo único - A declaração de inidoneidade poderá ocorrer também na hipótese prevista no art. 593, como sanção complementar.";"";"";""
"J";"11777460000147";"FABIO JUNIO ROSA FRAGA EIRELLI";"FABIO JUNIO ROSA FRAGA EIRELI";"AC TRANSPORTES ME";"024/2019";"Impedimento - Legislação Municipal";"16/03/2020";"16/03/2022";"Prefeitura Municipal de Vitória da Conquista (BA)";"BA";"Prefeitura Municipal de Vitória da Conquista (BA)";"04/02/2021";"16/03/2020";"Diário Oficial do Município Seção I Pagina 33";"";"Todas as Esferas em todos os Poderes";"Art. 61, Decreto 18484/2018";"Art. 6 1 Exclusivamente, nos processoslicitatórios realizados sob a modalidadepregão, ao fornecedor que, convocadodentro do prazo de validade de suaproposta, não celebrar o contrato, deixarde entregar ou apresentar documentaçãofalsa exigida para o certame, ensejar oretardamento da execução do seu objeto,comportar-se de modo inidôneo oucometer fraude fiscal, será aplicadapenalidade de impedimento de licitar econtratar com o Município, por prazo nãosuperior a 5 (cinco) anos, sendodescredenciado do Sistema de Cadastrode Fornecedores, sem prejuízo dasmultas previstas em edital e no contrato edas demais cominações legais, aplicadase dosadas segundo a natureza e agravidade da falta cometida.";"16/03/2020";"";""
"""

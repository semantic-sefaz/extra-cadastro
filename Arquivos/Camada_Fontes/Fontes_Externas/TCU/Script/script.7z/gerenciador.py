from bs4 import BeautifulSoup
import requests
import re
import os
import shutil
import json
from datetime import date
import time
import csv
import subprocess

PATH_INABILITADOS = 'inabilitados/'
PATH_INIDONEOS = 'inidoneos/'
PATH_PROCESSO = 'processo/'
PATH_LOG = 'log/'

URL_INABILITADOS = "https://contas.tcu.gov.br/ords/condenacao/consulta/inabilitados"
URL_INIDONEOS = "https://contas.tcu.gov.br/ords/condenacao/consulta/inidoneos"

arq_inab_json = False
arq_inab_csv = False
arq_inid_json = False
arq_inid_csv = False
arq_proc_csv = False

path_sqlldr = "C:\\oraclexe\\app\\oracle\\product\\11.2.0\\server\\bin\\"
#path_sqlldr_sefaz = "/u01/app/oracle/product/12.2.0/db_1/bin/"
path_carga = "C:\\proj-sefaz-ma\\rfb-sefaz-ma\\talarico\\log\\"

username = 'ufc2'#'lano'
password = 'homo234'#'lanobl'
dsn = '172.20.3.59/homo01'#'localhost/xe'
port = 1521
encoding_db = 'UTF-8'
banco_dados = "//172.20.3.59:1521/homo01"#"xe"

arq_ctl_tcu_fornecedor_inabilitado = "tcu_fornecedor_inabilitado.ctl"
arq_ctl_tcu_fornecedor_inidoneo = "tcu_fornecedor_inidoneo.ctl"
arq_ctl_tcu_fornecedor_processo = "tcu_processo.ctl"

#cria diretorios
if not os.path.isdir(PATH_INABILITADOS): #Diretório de arquivos não existe
    os.mkdir(PATH_INABILITADOS)
if not os.path.isdir(PATH_INIDONEOS): #Diretório de arquivos não existe
    os.mkdir(PATH_INIDONEOS)
if not os.path.isdir(PATH_PROCESSO): #Diretório de arquivos não existe
    os.mkdir(PATH_PROCESSO)
if not os.path.isdir(PATH_LOG): #Diretório de arquivos não existe
    os.mkdir(PATH_LOG)

#remove arquivos de carga anteriores
for file in os.listdir(PATH_INABILITADOS):
    os.remove(PATH_INABILITADOS+file)
for file in os.listdir(PATH_INIDONEOS):
    os.remove(PATH_INIDONEOS+file)
for file in os.listdir(PATH_PROCESSO):
    os.remove(PATH_PROCESSO+file)

#baixa json inabilitados
print("Solicitando página do TCU em ",URL_INABILITADOS)
page = requests.get(URL_INABILITADOS)
arquivo = page.json()

with open(PATH_INABILITADOS+"dados_inabilitados.json","w",encoding='utf-8') as register_file:
    print("Criando arquivo json inabilitados...")
    register_file.write(json.dumps(arquivo, ensure_ascii=False))

if os.path.isfile(PATH_INABILITADOS+"dados_inabilitados.json"):
    if os.stat(PATH_INABILITADOS+"dados_inabilitados.json")[6] == 0.0:
        print("Falha na criação do arquivo dados_inabilitados.json")
    else:
        arq_inab_json = True
        print("OK!")

#baixa json inidoenos
print("Solicitando página do TCU em ",URL_INIDONEOS)
page = requests.get(URL_INIDONEOS)
arquivo = page.json()

with open(PATH_INIDONEOS+"dados_inidoneos.json","w",encoding='utf-8') as register_file:
    print("Criando arquivo json inidoneos...")
    register_file.write(json.dumps(arquivo, ensure_ascii=False))

if os.path.isfile(PATH_INIDONEOS+"dados_inidoneos.json"):
    if os.stat(PATH_INIDONEOS+"dados_inidoneos.json")[6] == 0.0:
        print("Falha na criação do arquivo dados_inidoneos.json")
    else:
        arq_inid_json = True
        print("OK!")

#cria csv inabilitados
if arq_inab_json:
    with open(PATH_INABILITADOS+"dados_inabilitados.json","r",encoding='utf-8') as register_file:
        print("Convertendo json para csv do arquivo inabilitados...")
        register = json.load(register_file)
        #print(register["items"][0]["nome"]+";"+register["items"][0]["cpf"]+";"+register["items"][0]["processo"]+";"+register["items"][0]["deliberacao"]+";"+register["items"][0]["uf"])
        f = open(PATH_INABILITADOS+"tcu_fornecedor_inabilitado.csv","w", newline='',encoding='utf-8')
        print("Criando arquivo csv inabilitados...")
        w = csv.writer(f)
        for item in register["items"]:
            #print(item["nome"]+";"+item["cpf"]+";"+item["processo"]+";"+item["deliberacao"]+";"+item["uf"])
            #w.writerow([item["nome"],item["cpf"],item["processo"],item["deliberacao"],item["uf"],item["municipio"]])
            w.writerow([item["cpf"],item["nome"],item["uf"],item["municipio"]])
        #w.close()
if os.path.isfile(PATH_INABILITADOS+"tcu_fornecedor_inabilitado.csv"):
    if os.stat(PATH_INABILITADOS+"tcu_fornecedor_inabilitado.csv")[6] == 0.0:
        print("Falha na criação do arquivo tcu_fornecedor_inabilitado.csv")
    else:
        arq_inab_csv = True
        print("OK!")

#cria csv inidoneos
if arq_inid_json:
    with open(PATH_INIDONEOS+"dados_inidoneos.json","r",encoding='utf-8') as register_file:
        print("Convertendo json para csv do arquivo inidoneos...")
        register = json.load(register_file)
        f = open(PATH_INIDONEOS+"tcu_fornecedor_inidoneo.csv","w", newline='',encoding='utf-8')
        print("Criando arquivo csv inidoneos...")
        w = csv.writer(f)
        for item in register["items"]:
            w.writerow([item["cpf_cnpj"],item["nome"]])

if os.path.isfile(PATH_INIDONEOS+"tcu_fornecedor_inidoneo.csv"):
    if os.stat(PATH_INIDONEOS+"tcu_fornecedor_inidoneo.csv")[6] == 0.0:
        print("Falha na criação do arquivo tcu_fornecedor_inidoneo.csv")
    else:
        arq_inab_csv = True
        print("OK!")

#cria csv processos
if arq_inab_json and arq_inid_json:
    f = open(PATH_PROCESSO+"tcu_processo.csv","w", newline='',encoding='utf-8')
    print("Criando arquivo csv processo...")
    w = csv.writer(f)
    with open(PATH_INABILITADOS+"dados_inabilitados.json","r",encoding='utf-8') as register_file:
        print("Extraindo dados do arquivo inabilitados...")
        register = json.load(register_file)
        for item in register["items"]:
            w.writerow([item["processo"],item["deliberacao"],item["data_transito_julgado"],item["data_acordao"],item["data_final"],item["cpf"],"TCU"])

    with open(PATH_INIDONEOS+"dados_inidoneos.json","r",encoding='utf-8') as register_file:
        print("Extraindo dados do arquivo inidoneos...")
        register = json.load(register_file)
        for item in register["items"]:
            w.writerow([item["processo"],item["deliberacao"],item["data_transito_julgado"],item["data_acordao"],item["data_final"],item["cpf_cnpj"]])

if os.path.isfile(PATH_PROCESSO+"tcu_processo.csv"):
    if os.stat(PATH_PROCESSO+"tcu_processo.csv")[6] == 0.0:
        print("Falha na criação do arquivo tcu_processo.csv")
    else:
        arq_proc_csv = True
        print("OK!")

#faz a carga em tcu_fornecedor_inabilitados
if arq_inab_csv:
    sql_loader = "{0}sqlldr userid={1}/{2}@{3} control={4}{5} log={4}inabilitados.log".format(path_sqlldr,username,password,banco_dados,path_carga,arq_ctl_tcu_fornecedor_inabilitado)
    ldr_inab = subprocess.call(sql_loader, shell=True)

if os.path.isfile(path_carga+"tcu_fornecedor_inabilitado.bad"):
    if os.stat(path_carga+"tcu_fornecedor_inabilitado.bad")[6] == 0.0:
        print("Falha na carga da tabela tcu_fornecedor_inabilitado")
    else:
        arq_inab_csv = True
        print("OK!")
    
#faz a carga em tcu_fornecedor_inidoneos
if arq_inid_csv:
    sql_loader = "{0}sqlldr userid={1}/{2}@{3} control={4}{5} log={4}inidoneos.log".format(path_sqlldr,username,password,banco_dados,path_carga,arq_ctl_tcu_fornecedor_inidoneo)
    ldr_inid = subprocess.call(sql_loader, shell=True)

if os.path.isfile(path_carga+"tcu_fornecedor_inidoneo.bad"):
    if os.stat(path_carga+"tcu_fornecedor_inidoneo.bad")[6] == 0.0:
        print("Falha na carga da tabela tcu_fornecedor_inidoneo")
    else:
        arq_inab_csv = True
        print("OK!")

#faz a carga em tcu_fornecedor_inabilitados
if arq_proc_csv:
    sql_loader = "{0}sqlldr userid={1}/{2}@{3} control={4}{5} log={4}processo.log".format(path_sqlldr,username,password,banco_dados,path_carga,arq_ctl_tcu_fornecedor_processo)
    ldr_proc = subprocess.call(sql_loader, shell=True)

if os.path.isfile(path_carga+"tcu_processo.bad"):
    if os.stat(path_carga+"tcu_processo.bad")[6] == 0.0:
        print("Falha na carga da tabela tcu_processo")
    else:
        arq_proc_csv = True
        print("OK!")

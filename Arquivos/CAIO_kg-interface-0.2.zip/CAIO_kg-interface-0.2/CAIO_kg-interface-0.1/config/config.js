
/**********************
*** CONFIG FILE ***
**********************/

var config = new Object();

// SPARQL
config.sparqlBase = "http://localhost:7200/repositories/Enderecos";
config.resultBase = "http://localhost:7200/repositories/Enderecos";
config.externalBase = "http://localhost:7200/repositories/Enderecos";
config.resourceBase = "http://localhost:7200/graphs-visualizations"

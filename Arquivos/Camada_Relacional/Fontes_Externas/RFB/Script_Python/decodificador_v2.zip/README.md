# decodificador_v2.0
Um projeto gerenciador de carga de dados da RFB no banco Oracle e gerador de um EKG no Virtuoso
